  <?php phpinfo();?> 
